
  # Sri Lankan Community App

  This is a code bundle for Sri Lankan Community App. The original project is available at https://www.figma.com/design/DAkd1MjWvQyoTxsVrbmcxg/Sri-Lankan-Community-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  